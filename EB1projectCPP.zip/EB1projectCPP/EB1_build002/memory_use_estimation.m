% Memory estimation

pts_per_frame = 5000;
frame_num = 300; % This is also the maximum lifespan

total_point_num = pts_per_frame * frame_num;

pt_per_track = 3;

total_track_num = total_point_num / pt_per_track;

memory_per_record = 20; % byte

total_memory = total_track_num * frame_num * memory_per_record * 1.0e-6; % multiplied by 1.0e-6 to convert to MB

fprintf('Total memory needed in MB is %f\n', total_memory);

fprintf('Memory effective use rate is %f percent\n', 100 * total_point_num * memory_per_record * 1.0e-6/total_memory); 

% Actually, if the rate of use can reach higher, this number will be
% significantly reduced. 