extern void extendPointList(frm_Frame &pointList, int newLen);
extern void cleanSequence(frm_Sequence &s);
